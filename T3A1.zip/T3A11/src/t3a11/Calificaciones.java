package t3a11;

import java.util.Scanner;

public class Calificaciones {

    private String nombreAsignatura2;
    private int calificacion2;
    private String nombre; 
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String grupo; 
    private String carrera; 
    private String nombreAsignatura;
    private int calificacion;
    private double promedio;       

    public Calificaciones() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrrera) {
        this.carrera = carrera;
    }

    public String getNombreAsignatura() {
        return nombreAsignatura;
    }

    public void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = (calificacion+calificacion2)/2;
    }
    
    public String getNombreAsignatura2() {
        return nombreAsignatura2;
    }

    public void setNombreAsignatura2(String nombreAsignatura2) {
        this.nombreAsignatura2 = nombreAsignatura2;
    }
    
    public int getCalificacion2() {
        return calificacion2;
    }

    public void setCalificacion2(int calificacion2) {
        this.calificacion2 = calificacion2;
    }
    
}
